import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import urllib.request
import re
import json
import time
from urllib.parse import urlencode, parse_qsl

# --- CONFIGURACIÓN ---
M3U_URL = "https://raw.githubusercontent.com/whoisnoz3/acesm3u/main/lista.m3u"

ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

def build_url(query):
    return BASE_URL + '?' + urlencode(query)

def get_m3u_content(url):
    try:
        req = urllib.request.Request(f"{url}?t={int(time.time())}", headers={'User-Agent': 'Mozilla/5.0'})
        return urllib.request.urlopen(req, timeout=15).read().decode('utf-8')
    except:
        return None

def parse_m3u_by_type():
    data = get_m3u_content(M3U_URL)
    if not data: return {}, {}
    
    ace_groups = {}
    iptv_groups = {}
    lines = data.splitlines()
    current_label = None
    
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#EXTM3U"): continue
        
        if line.startswith("#EXTINF"):
            full_name = line.split(",")[-1].strip()
            match = re.search(r"^(.*?)\s*\((.*)\)$", full_name)
            if match:
                current_event, current_option = match.group(1).strip(), match.group(2).strip()
            else:
                current_event, current_option = full_name, "Principal"
            current_label = {'event': current_event, 'option': current_option}
            
        elif current_label:
            target_dict = None
            if "acestream://" in line:
                target_dict = ace_groups
            elif line.startswith("http"):
                target_dict = iptv_groups
            
            if target_dict is not None:
                ev = current_label['event']
                if ev not in target_dict: target_dict[ev] = []
                target_dict[ev].append({'label': current_label['option'], 'url': line})
                current_label = None

    return ace_groups, iptv_groups

def list_main_menu():
    # Menú Principal con dos secciones
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "La Chabola - Inicio")
    
    # Sección Ace Stream
    url_ace = build_url({'action': 'list_category', 'type': 'ace'})
    li_ace = xbmcgui.ListItem(label="[COLOR yellow][B]⚡ SECCIÓN ACE STREAM[/B][/COLOR]")
    li_ace.setArt({'icon': 'DefaultVideo.png'})
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url_ace, listitem=li_ace, isFolder=True)
    
    # Sección IPTV
    url_iptv = build_url({'action': 'list_category', 'type': 'iptv'})
    li_iptv = xbmcgui.ListItem(label="[COLOR aqua][B]📺 SECCIÓN IPTV DIRECTO[/B][/COLOR]")
    li_iptv.setArt({'icon': 'DefaultVideo.png'})
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url_iptv, listitem=li_iptv, isFolder=True)
    
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_category(content_type):
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    ace_data, iptv_data = parse_m3u_by_type()
    
    # Seleccionamos qué datos mostrar
    canales = ace_data if content_type == 'ace' else iptv_data
    titulo = "Ace Stream" if content_type == 'ace' else "IPTV"
    xbmcplugin.setPluginCategory(ADDON_HANDLE, f"La Chabola - {titulo}")

    for nombre_canal, enlaces in canales.items():
        url = build_url({
            'action': 'list_options', 
            'links': json.dumps(enlaces),
            'title': nombre_canal
        })
        li = xbmcgui.ListItem(label=f"[B]{nombre_canal}[/B]")
        li.setInfo('video', {'title': nombre_canal, 'plot': f"Opciones: {len(enlaces)}"})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_options(links_json, title):
    enlaces = json.loads(links_json)
    for enlace in enlaces:
        url = build_url({'action': 'play', 'url': enlace['url']})
        label = f"▶ {title} ({enlace['label']})"
        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {'title': label, 'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def play_item(url):
    if "acestream://" in url:
        ace_id = url.split("://")[-1].strip()
        final_path = f"plugin://script.module.horus/?action=play&id={ace_id}"
    else:
        final_path = url
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, xbmcgui.ListItem(path=final_path))

# --- ROUTER ---
args = dict(parse_qsl(sys.argv[2][1:]))
action = args.get("action")

if action is None:
    list_main_menu()
elif action == "list_category":
    list_category(args.get('type'))
elif action == "list_options":
    list_options(args.get('links'), args.get('title'))
elif action == "play":
    play_item(args.get('url'))